#include <SFML\Graphics.hpp>
#include <string>
#ifndef GAME_H_INCLUDED
#define GAME_H_INCLUDED
#endif //!GAME_H_INCLUDED
#ifndef MAIN_H_INCLUDED
#endif // !MAIN_H_INCLUDED
class Game { //la classe principale del gioco
public:
	bool run(); // il loop principale del gioco
	sf::Sprite ball, paddle1, paddle2; 
public:
	bool initialize(); //inizializza il gioco alla situazione di default
private:
	bool processEvents(); //processa gli input
	bool handlePlayerInput(sf::Keyboard::Key key, bool isPressed); //gestisce la tastiera
	bool render(); //mostra ci� che � successo in quel frame
	bool update(sf::Time deltatime); //aggiorna il frame
	bool loadTexture(sf::Sprite sprite, std::string path); //carica una texture in uno sprite
};