/*Pong
 *Autore: Carmine
 *Changelog:
 *	0.1:
 *
 */
#include <SFML\Graphics.hpp>
#include <string>
#include <stdexcept>
#include <iostream>
#include <conio.h>
#include <cstdlib>
#include <time.h>
#include "../main.h"
sf::VideoMode gameMode = sf::VideoMode::getDesktopMode();
sf::RenderWindow gameWindow(gameMode, "Pong(by Carmine)", sf::Style::Fullscreen);
sf::RectangleShape ball(sf::Vector2f(5,5));
sf::RectangleShape leftPaddle(sf::Vector2f(5, 30));
sf::RectangleShape rightPaddle(sf::Vector2f(5, 30));
sf::Drawable *sprites[3] {&ball, &leftPaddle, &rightPaddle};
std::size_t spriteSize = 3;
float leftPaddleMovement = 0.0f;
float lastBallInit = -300.0f;
sf::Vector2f ballMovement;
class loadingError : public std::runtime_error {
public:
	loadingError(std::string what_arg) :
		runtime_error(what_arg) {}
};
int main(int argc, char **argv) {
	try {
		bool wantToSetTimePerFrame = false;
		for (auto i = 0; i < argc; i++)
		{
			if (argv[i] == "-setVsync=true") gameWindow.setVerticalSyncEnabled(true);
			if (argv[i] == "-wantToSetTimePerFrame")
			{
				wantToSetTimePerFrame = true;
			}
		}
		if (wantToSetTimePerFrame)
		{
			std::cout << "Frame Per Secondo: ";
			int FPS;
			std::cin >> FPS;
			timePerFrame = sf::seconds(1.0f / float(FPS));
		}
		initialize();
		run();
	}
	catch (std::runtime_error& e) {
		std::cerr << e.what();
		_getch();
		return 1;
	}
}
void initialize() { //carica il gioco alla posizione iniziale
	ball.setFillColor(sf::Color::Red);
	ball.setOrigin(ball.getSize().x / 2, ball.getSize().y / 2);
	ball.setPosition(gameMode.width / 2, gameMode.height / 2);
	leftPaddle.setOrigin(0.0f, 15.0f);
	leftPaddle.setPosition(0.0f, gameMode.height / 2);
	rightPaddle.setOrigin(5.0f, 15.0f);
	rightPaddle.setPosition(gameMode.width, gameMode.height / 2);
	initializeBallMovement();
	update(timePerFrame);
	render();
}
void loadTextureIntoSprite(sf::Sprite sprite, std::string path) { //carica un'immagine da un percorso specificato
	try {
		sf::Texture texture;										  //a uno sprite
		if (!texture.loadFromFile(path)) throw loadingError("Impossibile caricare file: " + path);
		sprite.setTexture(texture);
	}
	catch (loadingError& e) {
		std::cerr << e.what();
		exit(1);
	}
}
void run() {
	sf::Clock clock;
	sf::Time timeSinceLastUpdate = sf::Time::Zero;
	while (gameWindow.isOpen())
	{
		timeSinceLastUpdate += clock.restart();
		while (timeSinceLastUpdate > timePerFrame)
		{
			timeSinceLastUpdate -= timePerFrame;
			std::cout << "FPS: " << 1.0f / timeSinceLastUpdate.asSeconds() << std::endl;
			processEvents();
			update(timePerFrame);
		}
		render();
	}
}
void processEvents() {
	sf::Event e;
	while (gameWindow.pollEvent(e))
	{
		switch (e.type)
		{
		case sf::Event::Closed:
			gameWindow.close();
			break;
		case sf::Event::KeyPressed:
		{
			handlePlayerInput(e.key.code);
			break;
		}
		case sf::Event::KeyReleased:
			handlePlayerInput(sf::Event::KeyReleased);
			break;
		}
	}
	return;
}
void handlePlayerInput(sf::Keyboard::Key key) {
	switch (key)
	{
	case sf::Keyboard::Up:
		leftPaddleMovement = -300.0f;
		break;
	case sf::Keyboard::Down:
		leftPaddleMovement = 300.0f;
		break;
	}
}
void handlePlayerInput(sf::Event::EventType keyEvent) {
	switch (keyEvent)
	{
	case sf::Event::KeyReleased:
		leftPaddleMovement = 0.0f;
		break;
	}
}
void update(sf::Time deltatime) {
	if (leftPaddle.getPosition().y <= 15) if (leftPaddleMovement < 0.0f) leftPaddleMovement = 0.0f;
	if (leftPaddle.getPosition().y >= gameMode.height - 15) if (leftPaddleMovement > 0.0f) leftPaddleMovement = 0.0f;
	leftPaddle.move(sf::Vector2f(0.0f, leftPaddleMovement * deltatime.asSeconds()));
	if (rightPaddle.getPosition().y < ball.getPosition().y)
	{
		rightPaddle.move(0.0f, 150.0f * deltatime.asSeconds());
	}
	else if (rightPaddle.getPosition().y > ball.getPosition().y)
	{
		rightPaddle.move(0.0f, -150.0f * deltatime.asSeconds());
	}
	bounce(ball);
	ball.move(ballMovement * deltatime.asSeconds());
}
void render() {
	gameWindow.clear();
	for (int i = 0; i < spriteSize; i++)
	{
		gameWindow.draw(*(sprites[i]));
	}
	gameWindow.display();
}
void initializeBallMovement() {
	srand(time(NULL));
	ballMovement.x = (lastBallInit = -lastBallInit);
	ballMovement.y = ((rand() % 600) - 300);
}
void bounce(sf::RectangleShape shape) {
	if (ball.getPosition().x <= leftPaddle.getPosition().x + 5.0f && ((ball.getPosition().y >= leftPaddle.getPosition().y - 15.0f) && (ball.getPosition().y <= leftPaddle.getPosition().y + 15.0f)))
	{
		ballMovement.x = -ballMovement.x;
		ballMovement.y = (ball.getPosition().y - leftPaddle.getPosition().y) / 15.0f * 150.0f;
	}
	if (ball.getPosition().x >= rightPaddle.getPosition().x - 5.0f && ((ball.getPosition().y >= rightPaddle.getPosition().y - 15.0f) && (ball.getPosition().y <= rightPaddle.getPosition().y + 15.0f)))
	{
		ballMovement.x = -ballMovement.x;
		ballMovement.y = (ball.getPosition().y - rightPaddle.getPosition().y) / 15.0f * 150.0f;
	}
	if (ball.getPosition().x <= 2.5f || ball.getPosition().x >= sf::VideoMode::getDesktopMode().width - 2.5f)
	{
		ball.setPosition(sf::VideoMode::getDesktopMode().width / 2, sf::VideoMode::getDesktopMode().height / 2);
		initializeBallMovement();
	}
	if (ball.getPosition().y <= 2.5f || ball.getPosition().y >= gameMode.height - 2.5)
	{
		ballMovement.y = -ballMovement.y;
	}
	
}
