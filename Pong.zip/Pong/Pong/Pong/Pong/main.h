#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED
#include <SFML\Graphics.hpp>
#include <string>
void initialize();
void loadTextureIntoSprite(sf::Sprite sprite, std::string path);
void processEvents();
void update(sf::Time deltatime);
void render();
void run();
enum class keyEventType : bool;
void handlePlayerInput(sf::Keyboard::Key key);
void handlePlayerInput(sf::Event::EventType keyEvent);
sf::Time timePerFrame = sf::seconds(1.0f / 60.0f);
void bounce(sf::RectangleShape shape);
void initializeBallMovement();
#endif // !MAIN_H_INCLUDED
